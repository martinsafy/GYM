# IronPulse Gym — Frontend

Angular 22 frontend لنظام إدارة الجيم (Gym Management System)، متصل بالباك إند الموجود في مشروع `gym-api`.

## المتطلبات المغطّاة

| المطلوب | فين تلاقيه |
|---|---|
| Components | 13 كومبوننت |
| Data binding | في كل التمبليتس |
| Control flow (`@if` / `@for`) | في كل الـ html |
| Signals | `signal()` في أغلب الكومبوننتس |
| Template-driven form | `signin-form` |
| Signal form | `signup-form` |
| Reactive form | `add-class-form`, `add-trainer-form` |
| HttpClient | في كل الـ services |
| Interceptors (auth + error) | `interceptors/` |
| Services | `auth-service`, `classes-service`, `trainers-service`, `user-service` |
| Routing + routerLink + navigateByUrl/navigate | في كل الكومبوننتس |
| Route params | `class-details/:id`, `edit-class/:id`, `edit-trainer/:id` |
| Child routes | تحت `admin-dashboard` و `member-dashboard` |
| Route Guards | `admin-guard`, `member-guard` |

## التشغيل

```bash
npm install
npm start
```

يفتح على `http://localhost:4200`. لازم الباك إند (`gym-api`) يكون شغّال على `http://localhost:5000` في نفس الوقت.

## حسابات تجريبية (من الـ seed بتاع الباك إند)

- أدمن: `admin@gym.com` / `admin12345`
- عضو: `member@gym.com` / `member12345`

## هيكل الصفحات

- `/home` — الصفحة الرئيسية، عرض كل الحصص مع فلاتر
- `/trainers` — عرض المدربين
- `/signin`, `/signup` — تسجيل الدخول والتسجيل
- `/class-details/:id` — تفاصيل حصة
- `/admin-dashboard` — لوحة تحكم الأدمن (إدارة الحصص والمدربين، Add/Update/Delete)
- `/member-dashboard` — لوحة العضو (الحصص المشترك فيها)

## ملاحظة

الباك إند لازم يكون شغّال على البورت 5000 قبل ما تفتح الفرونت، وإلا هتلاقي الصفحات فاضية والـ console فيه أخطاء اتصال.
