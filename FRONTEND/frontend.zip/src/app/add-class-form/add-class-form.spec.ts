import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddClassForm } from './add-class-form';

describe('AddClassForm', () => {
  let component: AddClassForm;
  let fixture: ComponentFixture<AddClassForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddClassForm],
    }).compileComponents();

    fixture = TestBed.createComponent(AddClassForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
