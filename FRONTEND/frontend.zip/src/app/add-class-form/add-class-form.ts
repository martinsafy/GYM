import { Component, inject, OnInit, signal } from '@angular/core';
import { CLASS_CATEGORIES, CLASS_LEVELS } from '../constants/class-constants';
import { TitleCasePipe } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ClassesService } from '../services/classes-service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  imports: [TitleCasePipe, ReactiveFormsModule],
  selector: 'app-add-class-form',
  styleUrl: './add-class-form.css',
  templateUrl: './add-class-form.html',
})
export class AddClassForm implements OnInit {
  categories = CLASS_CATEGORIES;
  levels = CLASS_LEVELS;

  classesService = inject(ClassesService);
  route = inject(ActivatedRoute);
  router = inject(Router);

  errorMessage = signal('');
  successMessage = signal('');
  loading = signal(false);

  editingClassId = signal<string | null>(null);
  currentImageUrl = signal<string>('');

  selectedFile: File | null = null;

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  classForm = new FormGroup({
    title: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(100),
    ]),
    trainer: new FormControl('', [Validators.required]),
    category: new FormControl('', [Validators.required]),
    level: new FormControl('', [Validators.required]),
    price: new FormControl(0, [Validators.required, Validators.min(0)]),
    duration: new FormControl(0, [Validators.required, Validators.min(0)]),
    capacity: new FormControl(20, [Validators.required, Validators.min(1)]),
    rating: new FormControl(0, [Validators.min(0), Validators.max(5)]),
    schedule: new FormControl(''),
    description: new FormControl('', [Validators.maxLength(1000)]),
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.editingClassId.set(id);
      this.classesService.getClassById(id).subscribe({
        next: (gymClass) => {
          this.currentImageUrl.set(gymClass.imageUrl || '');
          this.classForm.patchValue({
            title: gymClass.title,
            trainer: gymClass.trainer,
            category: gymClass.category,
            level: gymClass.level,
            price: gymClass.price,
            duration: gymClass.duration,
            capacity: gymClass.capacity ?? 20,
            rating: gymClass.rating ?? 0,
            schedule: gymClass.schedule ?? '',
            description: gymClass.description ?? '',
          });
        },
        error: () => {
          this.errorMessage.set('Failed to load class data for editing.');
        },
      });
    }
  }

  buildFormData(): FormData {
    const formData = new FormData();
    const formValues = this.classForm.value;

    Object.keys(formValues).forEach((key) => {
      const value = (formValues as any)[key];
      if (value !== null && value !== undefined && value !== '') {
        formData.append(key, value);
      }
    });

    if (this.selectedFile) {
      formData.append('imageUrl', this.selectedFile);
    }

    return formData;
  }

  onSubmit() {
    this.errorMessage.set('');
    this.successMessage.set('');

    if (this.classForm.invalid) {
      this.classForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    const formData = this.buildFormData();
    const id = this.editingClassId();

    const request$ = id
      ? this.classesService.updateClass(formData, id)
      : this.classesService.addClass(formData);

    request$.subscribe({
      next: () => {
        this.loading.set(false);
        this.successMessage.set(id ? 'Class updated successfully.' : 'Class created successfully.');

        setTimeout(() => {
          this.router.navigateByUrl('/admin-dashboard');
        }, 900);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMessage.set(err?.message || (id ? 'Failed to update class.' : 'Failed to add class.'));
      },
    });
  }
}
