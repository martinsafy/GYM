import { Routes } from '@angular/router';
import { SigninForm } from './signin-form/signin-form';
import { SignupForm } from './signup-form/signup-form';
import { ClassesList } from './classes-list/classes-list';
import { ClassDetails } from './class-details/class-details';
import { TrainersList } from './trainers-list/trainers-list';
import { AdminDashboard } from './admin-dashboard/admin-dashboard';
import { ClassManagement } from './class-management/class-management';
import { AddClassForm } from './add-class-form/add-class-form';
import { TrainerManagement } from './trainer-management/trainer-management';
import { AddTrainerForm } from './add-trainer-form/add-trainer-form';
import { MemberDashboard } from './member-dashboard/member-dashboard';
import { MemberClasses } from './member-classes/member-classes';
import { adminGuard } from './guards/admin-guard';
import { memberGuard } from './guards/member-guard';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: ClassesList, title: 'Home' },
  { path: 'signin', component: SigninForm, title: 'Sign In' },
  { path: 'signup', component: SignupForm, title: 'Sign Up' },
  { path: 'trainers', component: TrainersList, title: 'Trainers' },
  {
    path: 'class-details/:id',
    component: ClassDetails,
    title: 'Class Details',
  },

  {
    path: 'admin-dashboard',
    component: AdminDashboard,
    canActivate: [adminGuard],
    children: [
      { path: '', component: ClassManagement, title: 'Manage Classes' },
      { path: 'add-class', component: AddClassForm, title: 'Add Class' },
      { path: 'edit-class/:id', component: AddClassForm, title: 'Edit Class' },
      { path: 'trainers', component: TrainerManagement, title: 'Manage Trainers' },
      { path: 'add-trainer', component: AddTrainerForm, title: 'Add Trainer' },
      { path: 'edit-trainer/:id', component: AddTrainerForm, title: 'Edit Trainer' },
    ],
  },

  {
    path: 'member-dashboard',
    component: MemberDashboard,
    title: 'Member Dashboard',
    canActivate: [memberGuard],
    children: [{ path: '', component: MemberClasses, title: 'My Classes' }],
  },

  { path: '**', redirectTo: 'home' },
];
