import { Component, inject, OnInit, signal } from '@angular/core';
import { ClassInterface } from '../interfaces/class-interface';
import { UserService } from '../services/user-service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-member-classes',
  imports: [RouterLink],
  templateUrl: './member-classes.html',
  styleUrl: './member-classes.css',
})
export class MemberClasses implements OnInit {
  classes = signal<ClassInterface[]>([]);
  userService = inject(UserService);
  errorMessage = signal<string | null>(null);

  ngOnInit(): void {
    this.loadClasses();
  }

  loadClasses() {
    this.userService.getMyClasses().subscribe({
      next: (data) => {
        this.classes.set(data);
      },
      error: (err) => {
        this.errorMessage.set('Failed to load your classes. Please try again later.');
        console.error(err);
      },
    });
  }

  cancel(classId: string) {
    if (!confirm('Cancel your enrollment in this class?')) {
      return;
    }

    this.userService.cancelEnrollment(classId).subscribe({
      next: (data) => {
        this.classes.set(data);
      },
      error: (err) => {
        this.errorMessage.set('Failed to cancel enrollment.');
        console.error(err);
      },
    });
  }
}
