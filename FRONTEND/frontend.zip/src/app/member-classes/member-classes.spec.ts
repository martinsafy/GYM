import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MemberClasses } from './member-classes';

describe('MemberClasses', () => {
  let component: MemberClasses;
  let fixture: ComponentFixture<MemberClasses>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MemberClasses],
    }).compileComponents();

    fixture = TestBed.createComponent(MemberClasses);
    component = fixture.componentInstance;
    await fixture.whenStable();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
