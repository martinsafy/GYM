import { Component, inject, signal, ViewChild } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../services/auth-service';

@Component({
  imports: [FormsModule, RouterLink],
  selector: 'app-signin-form',
  styleUrl: './signin-form.css',
  templateUrl: './signin-form.html',
})
export class SigninForm {
  @ViewChild('loginForm') login!: NgForm;

  authService = inject(AuthService);

  errorMessage = signal('');
  loading = signal(false);

  onSubmit() {
    this.errorMessage.set('');
    this.loading.set(true);

    this.authService.signin(this.login.value).subscribe({
      next: () => {
        this.loading.set(false);
        this.login.reset();
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMessage.set(err?.message || 'Failed to sign in. Please try again.');
      },
    });
  }
}
