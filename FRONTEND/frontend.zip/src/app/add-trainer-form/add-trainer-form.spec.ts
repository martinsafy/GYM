import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddTrainerForm } from './add-trainer-form';

describe('AddTrainerForm', () => {
  let component: AddTrainerForm;
  let fixture: ComponentFixture<AddTrainerForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddTrainerForm],
    }).compileComponents();

    fixture = TestBed.createComponent(AddTrainerForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
