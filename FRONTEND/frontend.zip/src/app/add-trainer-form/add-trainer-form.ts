import { Component, inject, OnInit, signal } from '@angular/core';
import { CLASS_CATEGORIES } from '../constants/class-constants';
import { TitleCasePipe } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { TrainersService } from '../services/trainers-service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  imports: [TitleCasePipe, ReactiveFormsModule],
  selector: 'app-add-trainer-form',
  styleUrl: './add-trainer-form.css',
  templateUrl: './add-trainer-form.html',
})
export class AddTrainerForm implements OnInit {
  specialities = CLASS_CATEGORIES;

  trainersService = inject(TrainersService);
  route = inject(ActivatedRoute);
  router = inject(Router);

  errorMessage = signal('');
  successMessage = signal('');
  loading = signal(false);
  editingTrainerId = signal<string | null>(null);
  currentImageUrl = signal('');

  selectedFile: File | null = null;

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  trainerForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(80),
    ]),
    speciality: new FormControl('', [Validators.required]),
    experienceYears: new FormControl(0, [Validators.min(0)]),
    phone: new FormControl(''),
    bio: new FormControl('', [Validators.maxLength(1000)]),
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.editingTrainerId.set(id);
      this.trainersService.getTrainerById(id).subscribe({
        next: (trainer) => {
          this.currentImageUrl.set(trainer.imageUrl || '');
          this.trainerForm.patchValue({
            name: trainer.name,
            speciality: trainer.speciality,
            experienceYears: trainer.experienceYears ?? 0,
            phone: trainer.phone ?? '',
            bio: trainer.bio ?? '',
          });
        },
        error: () => this.errorMessage.set('Failed to load trainer data for editing.'),
      });
    }
  }

  buildFormData(): FormData {
    const formData = new FormData();
    const formValues = this.trainerForm.value;

    Object.keys(formValues).forEach((key) => {
      const value = (formValues as any)[key];
      if (value !== null && value !== undefined && value !== '') {
        formData.append(key, value);
      }
    });

    if (this.selectedFile) {
      formData.append('imageUrl', this.selectedFile);
    }

    return formData;
  }

  onSubmit() {
    this.errorMessage.set('');
    this.successMessage.set('');

    if (this.trainerForm.invalid) {
      this.trainerForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    const formData = this.buildFormData();
    const id = this.editingTrainerId();

    const request$ = id
      ? this.trainersService.updateTrainer(formData, id)
      : this.trainersService.addTrainer(formData);

    request$.subscribe({
      next: () => {
        this.loading.set(false);
        this.successMessage.set(id ? 'Trainer updated successfully.' : 'Trainer added successfully.');
        setTimeout(() => this.router.navigateByUrl('/admin-dashboard/trainers'), 900);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMessage.set(err?.message || 'Failed to save trainer.');
      },
    });
  }
}
