import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ClassInterface } from '../interfaces/class-interface';

@Injectable({ providedIn: 'root' })
export class ClassesService {
  private baseUrl = 'http://localhost:5000/api/v1/classes';

  private httpClient = inject(HttpClient);

  getAllClasses(filters?: { category?: string; level?: string; search?: string }): Observable<ClassInterface[]> {
    let params = '';
    if (filters) {
      const query = new URLSearchParams();
      if (filters.category) query.set('category', filters.category);
      if (filters.level) query.set('level', filters.level);
      if (filters.search) query.set('search', filters.search);
      const qs = query.toString();
      if (qs) params = `?${qs}`;
    }

    return this.httpClient
      .get<any>(`${this.baseUrl}${params}`)
      .pipe(map((res) => res.data.classes));
  }

  getClassById(classId: string): Observable<ClassInterface> {
    return this.httpClient
      .get<any>(`${this.baseUrl}/${classId}`)
      .pipe(map((res) => res.data.class));
  }

  addClass(gymClass: FormData): Observable<ClassInterface> {
    return this.httpClient
      .post<any>(this.baseUrl, gymClass)
      .pipe(map((res) => res.data.class));
  }

  updateClass(gymClass: FormData, classId: string): Observable<ClassInterface> {
    return this.httpClient
      .patch<any>(`${this.baseUrl}/${classId}`, gymClass)
      .pipe(map((res) => res.data.class));
  }

  deleteClass(classId: string): Observable<ClassInterface> {
    return this.httpClient
      .delete<any>(`${this.baseUrl}/${classId}`)
      .pipe(map((res) => res.data.class));
  }
}
