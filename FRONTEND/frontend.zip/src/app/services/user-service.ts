import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { ClassInterface } from '../interfaces/class-interface';

@Injectable({ providedIn: 'root' })
export class UserService {
  private baseUrl = 'http://localhost:5000/api/v1/users';

  httpClient = inject(HttpClient);

  getMyClasses(): Observable<ClassInterface[]> {
    return this.httpClient
      .get<any>(`${this.baseUrl}/classes`)
      .pipe(map((res) => res.data.myClasses));
  }

  enrollInClass(classId: string): Observable<ClassInterface[]> {
    return this.httpClient
      .post<any>(`${this.baseUrl}/classes`, { classId })
      .pipe(map((res) => res.data.myClasses));
  }

  cancelEnrollment(classId: string): Observable<ClassInterface[]> {
    return this.httpClient
      .delete<any>(`${this.baseUrl}/classes/${classId}`)
      .pipe(map((res) => res.data.myClasses));
  }
}
