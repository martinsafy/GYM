import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { TrainerInterface } from '../interfaces/trainer-interface';

@Injectable({ providedIn: 'root' })
export class TrainersService {
  private baseUrl = 'http://localhost:5000/api/v1/trainers';

  private httpClient = inject(HttpClient);

  getAllTrainers(): Observable<TrainerInterface[]> {
    return this.httpClient.get<any>(this.baseUrl).pipe(map((res) => res.data.trainers));
  }

  getTrainerById(trainerId: string): Observable<TrainerInterface> {
    return this.httpClient
      .get<any>(`${this.baseUrl}/${trainerId}`)
      .pipe(map((res) => res.data.trainer));
  }

  addTrainer(trainer: FormData): Observable<TrainerInterface> {
    return this.httpClient
      .post<any>(this.baseUrl, trainer)
      .pipe(map((res) => res.data.trainer));
  }

  updateTrainer(trainer: FormData, trainerId: string): Observable<TrainerInterface> {
    return this.httpClient
      .patch<any>(`${this.baseUrl}/${trainerId}`, trainer)
      .pipe(map((res) => res.data.trainer));
  }

  deleteTrainer(trainerId: string): Observable<TrainerInterface> {
    return this.httpClient
      .delete<any>(`${this.baseUrl}/${trainerId}`)
      .pipe(map((res) => res.data.trainer));
  }
}
