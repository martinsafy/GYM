import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { tap } from 'rxjs';
import { jwtDecode } from 'jwt-decode';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private baseUrl = 'http://localhost:5000/api/v1/auth';

  private httpClient = inject(HttpClient);

  isLoggedInSignal = signal(false);

  private getDecodedToken() {
    const token = localStorage.getItem('token');

    if (!token) {
      return null;
    }

    try {
      return jwtDecode<any>(token);
    } catch {
      return null;
    }
  }

  getRole(): string | null {
    const decoded = this.getDecodedToken();

    if (!decoded) {
      return null;
    }

    return decoded.role;
  }

  isLoggedIn() {
    const token = localStorage.getItem('token');
    if (!token) {
      this.isLoggedInSignal.set(false);
      return false;
    }

    try {
      const decoded = this.getDecodedToken();
      const expirationDate = new Date(decoded.exp * 1000);

      if (expirationDate < new Date()) {
        localStorage.removeItem('token');
        this.isLoggedInSignal.set(false);
        return false;
      }

      this.isLoggedInSignal.set(true);
      return true;
    } catch {
      localStorage.removeItem('token');
      this.isLoggedInSignal.set(false);
      return false;
    }
  }

  router = inject(Router);

  signin(credentials: { email: string; password: string }) {
    return this.httpClient.post<any>(`${this.baseUrl}/signin`, credentials).pipe(
      tap((res) => {
        this.isLoggedInSignal.set(true);
        localStorage.setItem('token', res.token);
        const role = this.getRole();

        if (role === 'admin') {
          this.router.navigate(['/admin-dashboard']);
        } else if (role === 'member') {
          this.router.navigate(['/member-dashboard']);
        }
      }),
    );
  }

  signup(userData: FormData) {
    return this.httpClient.post<any>(`${this.baseUrl}/signup`, userData).pipe(
      tap((res) => {
        this.isLoggedInSignal.set(true);
        localStorage.setItem('token', res.token);
        this.router.navigate(['/member-dashboard']);
      }),
    );
  }

  logout() {
    this.isLoggedInSignal.set(false);
    localStorage.removeItem('token');
    this.router.navigateByUrl('/home');
  }
}
