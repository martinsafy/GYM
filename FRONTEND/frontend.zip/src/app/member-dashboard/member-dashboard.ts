import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from '../services/auth-service';

@Component({
  imports: [RouterOutlet],
  selector: 'app-member-dashboard',
  styleUrl: './member-dashboard.css',
  templateUrl: './member-dashboard.html',
})
export class MemberDashboard {}
