import { Component, inject, OnInit, signal } from '@angular/core';
import { TrainersService } from '../services/trainers-service';
import { TrainerInterface } from '../interfaces/trainer-interface';
import { Router } from '@angular/router';
import { TitleCasePipe } from '@angular/common';

@Component({
  imports: [TitleCasePipe],
  selector: 'app-trainer-management',
  styleUrl: './trainer-management.css',
  templateUrl: './trainer-management.html',
})
export class TrainerManagement implements OnInit {
  trainersService = inject(TrainersService);
  router = inject(Router);

  trainers = signal<TrainerInterface[]>([]);
  errorMessage = signal('');

  ngOnInit(): void {
    this.loadTrainers();
  }

  loadTrainers() {
    this.trainersService.getAllTrainers().subscribe({
      next: (data) => this.trainers.set(data),
      error: (err) => {
        this.errorMessage.set('Failed to load trainers');
        console.error(err);
      },
    });
  }

  onAddTrainer() {
    this.router.navigateByUrl('/admin-dashboard/add-trainer');
  }

  onUpdate(trainerId: string) {
    this.router.navigateByUrl(`/admin-dashboard/edit-trainer/${trainerId}`);
  }

  onDelete(trainerId: string) {
    if (!confirm('Are you sure you want to delete this trainer?')) {
      return;
    }

    this.trainersService.deleteTrainer(trainerId).subscribe({
      next: () => {
        this.trainers.update((trainers) => trainers.filter((t) => t._id !== trainerId));
      },
      error: (err) => {
        this.errorMessage.set('Failed to delete trainer');
        console.error(err);
      },
    });
  }
}
