export interface TrainerInterface {
  _id: string;
  name: string;
  speciality: 'cardio' | 'strength' | 'yoga' | 'crossfit' | 'boxing' | 'pilates';
  bio?: string;
  experienceYears?: number;
  phone?: string;
  imageUrl?: string;
}
