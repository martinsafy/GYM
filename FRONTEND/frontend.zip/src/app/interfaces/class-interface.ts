export interface ClassInterface {
  _id: string;
  title: string;
  trainer: string;
  description: string;
  price: number;
  duration: number; // minutes
  category: 'cardio' | 'strength' | 'yoga' | 'crossfit' | 'boxing' | 'pilates';
  level: 'beginner' | 'intermediate' | 'advanced';
  rating?: number;
  capacity?: number;
  members?: number;
  availableSeats?: number;
  schedule?: string;
  imageUrl?: string;
}
