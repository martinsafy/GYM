import { Component, inject, OnInit, signal } from '@angular/core';
import { ClassesService } from '../services/classes-service';
import { ClassInterface } from '../interfaces/class-interface';
import { Router } from '@angular/router';
import { TitleCasePipe } from '@angular/common';

@Component({
  imports: [TitleCasePipe],
  selector: 'app-class-management',
  styleUrl: './class-management.css',
  templateUrl: './class-management.html',
})
export class ClassManagement implements OnInit {
  classesService = inject(ClassesService);
  router = inject(Router);

  classes = signal<ClassInterface[]>([]);
  errorMessage = signal('');

  ngOnInit(): void {
    this.loadClasses();
  }

  loadClasses() {
    this.classesService.getAllClasses().subscribe({
      next: (data) => {
        this.classes.set(data);
      },
      error: (err) => {
        this.errorMessage.set('Failed to load classes');
        console.error(err);
      },
    });
  }

  onAddClass() {
    this.router.navigateByUrl('/admin-dashboard/add-class');
  }

  onShow(classId: string) {
    this.router.navigateByUrl(`/class-details/${classId}`);
  }

  onUpdate(classId: string) {
    this.router.navigateByUrl(`/admin-dashboard/edit-class/${classId}`);
  }

  onDelete(classId: string) {
    if (!confirm('Are you sure you want to delete this class?')) {
      return;
    }

    this.classesService.deleteClass(classId).subscribe({
      next: () => {
        this.classes.update((classes) => classes.filter((c) => c._id !== classId));
      },
      error: (err) => {
        this.errorMessage.set('Failed to delete class');
        console.error(err);
      },
    });
  }
}
