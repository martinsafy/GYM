import { Component, inject, OnInit, signal } from '@angular/core';
import { TrainerInterface } from '../interfaces/trainer-interface';
import { TrainersService } from '../services/trainers-service';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-trainers-list',
  imports: [TitleCasePipe],
  templateUrl: './trainers-list.html',
  styleUrl: './trainers-list.css',
})
export class TrainersList implements OnInit {
  trainers = signal<TrainerInterface[]>([]);
  errorMessage = signal('');

  trainersService = inject(TrainersService);

  ngOnInit(): void {
    this.trainersService.getAllTrainers().subscribe({
      next: (data) => this.trainers.set(data),
      error: (err) => {
        this.errorMessage.set('Failed to load trainers.');
        console.error(err);
      },
    });
  }
}
