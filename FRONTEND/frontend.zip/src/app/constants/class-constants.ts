export const CLASS_CATEGORIES = [
  'cardio',
  'strength',
  'yoga',
  'crossfit',
  'boxing',
  'pilates',
] as const;

export const CLASS_LEVELS = ['beginner', 'intermediate', 'advanced'] as const;
