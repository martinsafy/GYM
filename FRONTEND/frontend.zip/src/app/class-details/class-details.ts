import { Component, inject, OnInit, signal } from '@angular/core';
import { ClassInterface } from '../interfaces/class-interface';
import { ClassesService } from '../services/classes-service';
import { ActivatedRoute, Router } from '@angular/router';
import { TitleCasePipe } from '@angular/common';
import { AuthService } from '../services/auth-service';
import { UserService } from '../services/user-service';

@Component({
  selector: 'app-class-details',
  imports: [TitleCasePipe],
  templateUrl: './class-details.html',
  styleUrl: './class-details.css',
})
export class ClassDetails implements OnInit {
  gymClass = signal<ClassInterface | undefined>(undefined);
  classId = signal('');
  message = signal('');

  classesService = inject(ClassesService);
  authService = inject(AuthService);
  userService = inject(UserService);
  activatedRoute = inject(ActivatedRoute);
  router = inject(Router);

  constructor() {
    this.activatedRoute.params.subscribe((params) => {
      this.classId.set(params['id']);
    });
  }

  ngOnInit(): void {
    this.classesService.getClassById(this.classId()).subscribe({
      next: (data) => {
        this.gymClass.set(data);
      },
    });
  }

  enroll() {
    if (!this.authService.isLoggedIn()) {
      this.router.navigateByUrl('/signin');
      return;
    }

    if (this.authService.getRole() !== 'member') {
      this.message.set('Only members can enroll in classes.');
      return;
    }

    this.userService.enrollInClass(this.classId()).subscribe({
      next: () => this.message.set('Enrolled successfully! Check "My Classes".'),
      error: (err) => this.message.set(err?.message || 'Could not enroll in this class.'),
    });
  }
}
