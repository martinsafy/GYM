import { Component, inject, OnInit, signal } from '@angular/core';
import { ClassInterface } from '../interfaces/class-interface';
import { ClassesService } from '../services/classes-service';
import { AuthService } from '../services/auth-service';
import { UserService } from '../services/user-service';
import { Router } from '@angular/router';
import { TitleCasePipe } from '@angular/common';
import { CLASS_CATEGORIES } from '../constants/class-constants';

@Component({
  selector: 'app-classes-list',
  imports: [TitleCasePipe],
  templateUrl: './classes-list.html',
  styleUrl: './classes-list.css',
})
export class ClassesList implements OnInit {
  classes = signal<ClassInterface[]>([]);
  categories = CLASS_CATEGORIES;
  activeCategory = signal<string>('all');

  classesService = inject(ClassesService);
  authService = inject(AuthService);
  userService = inject(UserService);
  router = inject(Router);

  errorMessage = signal('');
  enrollMessage = signal('');

  ngOnInit(): void {
    this.loadClasses();
  }

  loadClasses() {
    const category = this.activeCategory() === 'all' ? undefined : this.activeCategory();

    this.classesService.getAllClasses({ category }).subscribe({
      next: (data) => {
        this.classes.set(data);
      },
      error: (err) => {
        this.errorMessage.set('Failed to load classes. Please try again later.');
        console.error(err);
      },
    });
  }

  filterByCategory(category: string) {
    this.activeCategory.set(category);
    this.loadClasses();
  }

  enroll(classId: string, event: Event) {
    event.stopPropagation();

    if (!this.authService.isLoggedIn()) {
      this.router.navigateByUrl('/signin');
      return;
    }

    if (this.authService.getRole() !== 'member') {
      this.enrollMessage.set('Only members can enroll in classes.');
      return;
    }

    this.userService.enrollInClass(classId).subscribe({
      next: () => {
        this.enrollMessage.set('Enrolled successfully! Check "My Classes".');
        setTimeout(() => this.enrollMessage.set(''), 3000);
      },
      error: (err) => {
        this.enrollMessage.set(err?.message || 'Could not enroll in this class.');
        setTimeout(() => this.enrollMessage.set(''), 3000);
      },
    });
  }

  showClass(classId: string) {
    this.router.navigateByUrl(`class-details/${classId}`);
  }
}
